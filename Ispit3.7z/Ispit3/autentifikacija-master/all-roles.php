<?php

    require_once "core/init.php";

    Helper::getHeader('Home page');

    Helper::getNav();

    $roles = DB::getInstance()->get('*', 'roles')->results();

?>

<div class="row">
    <div class="col-lg-12">
        <div class="card m-5">
            <h5 class="card-title p-2">Sve Role</h5>
            <a href="create-roles.php" class="btn btn-warning" style="float:right">Kreiraj novu rolu</a>
            <div class="card-body">
                <table class="table table-hover">
                    <tr>
                        <th>R.B.</th>
                        <th>Naziv</th>
                        <th>Dozvole</th>
                        <th>Datum kreiranja</th>
                        <th>Akcija</th>
                    </tr>
                    <?php
                        foreach ($roles as $role) {
                            echo
                                "<tr>
                                    <td>$role->id</td>
                                    <td>$role->name</td>
                                    <td>$role->permissions</td>
                                    <td>$role->created</td>
                                    <td width=200>
                                        <a href='show-roles.php?id=$role->id'><button class='btn btn-primary btn-sm'>Prikaži</button></a>
                                        <a href='edit-roles.php?id=$role->id'><button class='btn btn-success btn-sm'>Uredi</button></a>
                                        <a href='remove-roles.php?id=$role->id'><button class='btn btn-danger btn-sm'>Obriši</button></a>
                                    </td>
                                </tr>";
                        }
                    ?>
                </table>
           
            </div>
        </div>
    </div>
</div>

<?php
    Helper::getFooter();
?>
