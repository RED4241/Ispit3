<?php

    require_once "core/init.php";

    Helper::getHeader('Home page');

    Helper::getNav();

    if (Input::exists('get')) {
        $roleId = Input::get('id');
        $role = DB::getInstance()->get('*', 'roles', ['id', '=', $roleId])->first();
    }

    if (Input::exists()) {
        $roleId = Input::get('id');
        $role = DB::getInstance()->delete('roles', ['id', '=', $roleId]);
        if (!$role->getError()) {
            // obavijesti korisnika o uspješnom brisanju i preusmjeri na neku drugu stranicu
            header("Location: all-roles.php");
        }
    }
?>

<div class="row">
    <div class="col-lg-8 offset-lg-2">
        <div class="card m-5">
            <h5 class="card-title p-2">Jeste li sigurni da želite obrisati rolu: <i><?php echo $role->id . ' - ' . $role->name ?></i></h5>
            <div class="card-body">
            <p>R:B: <?php echo $role->id ?></p>
                <p>Naziv: <?php echo $role->name ?></p>
                <p>Dozvole: <?php echo $role->permissions ?></p>
                <p>Datum Kreiranja: <?php echo $role->created ?></p>
            </div>
            <form method="post" class="p-3">
                <input type="hidden" name="id" value="<?php echo $roleId ?>">
                <a href="all-roles.php" class="btn btn-warning">Nazad</a>
                <button type="submit" name="submit" class="btn btn-primary" style="float:right">Potvrdi</button>
            </form>
        </div>
    </div>
</div>

<?php
    Helper::getFooter();
?>
