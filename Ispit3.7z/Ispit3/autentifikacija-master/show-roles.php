<?php

    require_once "core/init.php";

    Helper::getHeader('Home page');

    Helper::getNav();

    if (Input::exists('get')) {
        $roleId = Input::get('id');
        $role = DB::getInstance()->get('*', 'roles', ['id', '=', $roleId])->first();
    }
?>

<div class="row">
    <div class="col-lg-8 offset-lg-2">
        <div class="card m-5">
            <h5 class="card-title p-2">Informacije o roli br. <i><?php echo $role->id . ' - ' . $role->name ?></i></h5>
            <div class="card-body">
                <p>R:B: <?php echo $role->id ?></p>
                <p>Naziv: <?php echo $role->name ?></p>
                <p>Dozvole: <?php echo $role->permissions ?></p>
                <p>Datum Kreiranja: <?php echo $role->created ?></p>
                <a href="all-roles.php" class="btn btn-warning">Nazad</a>
            </div>
        </div>
    </div>
</div>

<?php
    Helper::getFooter();