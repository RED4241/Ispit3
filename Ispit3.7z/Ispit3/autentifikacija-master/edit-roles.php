<?php
  require_once "core/init.php";
  Helper::getHeader('Home Page');
  Helper::getNav();

  if (Input::exists('get')){
    $roleId = Input::get('id');
    $role = DB::getInstance()->get('*', 'roles', ['id', '=', $roleId])->first();
}

if (Input::exists('post')){
    //echo Input::get('first_name');
    $role = DB::getInstance()->update('roles', Input::get('id'), [
        'name' => Input::get('name'),
        'permissions' => Input::get('permissions'),
    ]);
    
    if (!$role->getError()){
        header("Location: all-roles.php");
    }
}
 
?>

<div class="row">
    <div class="col-lg-8 offset-lg-2" >
    <div class="card m-5">
    
    <h5 class="card-title p-2">Uredi korisnika</h5>
    <div class="card-body">
            <form method="POST">
            <input type="hidden" name="id" value="<?php echo $roleId?>">
            <div class="form-group">
                <label for="first_name">Naziv</label>
                <input type="text" class="form-control" id="name" name="name" value="<?php echo $role->id?>">
            </div>
            <div class="form-group">
                <label for="last_name">Dozvole</label>
                <input type="text" class="form-control" id="permissions" name="permissions" value="<?php echo $role->name?>">
            </div>
            <a href="all-roles.php" class="btn btn-warning">Nazad</a>
            <button type="submit" class="btn btn-primary" style="float:right">Uredi</button>
            </form>
        </div>    
        </div>    
    </div>
</div>
</div>
</div>

<?php
  Helper::getFooter();
?>