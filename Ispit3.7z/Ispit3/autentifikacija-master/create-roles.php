<?php
  require_once "core/init.php";
  Helper::getHeader('Home Page');
  Helper::getNav();

if (Input::exists()){
    //echo Input::get('first_name');
    $user = DB::getInstance()->insert('roles',[
        'name' => Input::get('name'),
        'permissions' => Input::get('permissions'),
    ]);
    
    if (!$user->getError()){
        header("Location: all-roles.php");
    }
}
 
?>

<div class="row">
    <div class="col-lg-8 offset-lg-2" >
    <div class="card m-5">
    
    <h5 class="card-title p-2">Stvori novu rolu:</h5>
    <div class="card-body">
            <form method="POST">
            <div class="form-group">
                <label for="first_name">Naziv</label>
                <input type="text" class="form-control" id="name" name="name" placeholder="Unesi naziv role" required>
            </div>
            <div class="form-group">
                <label for="last_name">Dozvole</label>
                <input type="text" class="form-control" id="permissions" name="permissions" placeholder="Unesi dozvole" required>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>    
        </div>    
    </div>
</div>
</div>
</div>

<?php
  Helper::getFooter();

?>